import React from 'react';
import { FileSpreadsheet, History, Settings, PlusCircle, LayoutDashboard } from 'lucide-react';

interface NavbarProps {
  currentTab: 'dashboard' | 'session' | 'history' | 'settings';
  setCurrentTab: (tab: 'dashboard' | 'session' | 'history' | 'settings') => void;
  resetSession: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, setCurrentTab, resetSession }) => {
  return (
    <header className="bg-slate-800 border-b border-slate-700 px-6 py-3.5 flex items-center justify-between sticky top-0 z-50">
      <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setCurrentTab('dashboard')}>
        <div className="bg-gradient-to-tr from-sky-500 to-indigo-600 p-2 rounded-lg text-white shadow-md">
          <FileSpreadsheet className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
            Smart Document Converter
            <span className="text-xs font-semibold uppercase px-2 py-0.5 bg-sky-500/20 text-sky-400 border border-sky-500/30 rounded-full">
              v1.0.0
            </span>
          </h1>
          <p className="text-xs text-slate-400">Dynamic Excel-to-Word Automated Engine</p>
        </div>
      </div>

      <nav className="flex items-center space-x-2">
        <button
          onClick={() => setCurrentTab('dashboard')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition ${
            currentTab === 'dashboard'
              ? 'bg-slate-700 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Dashboard</span>
        </button>

        <button
          onClick={() => {
            resetSession();
            setCurrentTab('session');
          }}
          className={`flex items-center space-x-1.5 px-3.5 py-1.5 rounded-md text-sm font-semibold transition shadow-sm ${
            currentTab === 'session'
              ? 'bg-sky-600 text-white hover:bg-sky-500'
              : 'bg-sky-700 text-sky-100 hover:bg-sky-600'
          }`}
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Conversion</span>
        </button>

        <button
          onClick={() => setCurrentTab('history')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition ${
            currentTab === 'history'
              ? 'bg-slate-700 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
          }`}
        >
          <History className="w-4 h-4" />
          <span>History</span>
        </button>

        <button
          onClick={() => setCurrentTab('settings')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition ${
            currentTab === 'settings'
              ? 'bg-slate-700 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>Settings</span>
        </button>
      </nav>
    </header>
  );
};
