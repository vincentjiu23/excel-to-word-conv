import React, { useEffect, useState } from 'react';
import { ApiService } from '../services/api';
import { ConversionRun } from '../types';
import {
  FileSpreadsheet,
  FileText,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Layers,
  History,
} from 'lucide-react';

interface DashboardScreenProps {
  onStartNew: () => void;
  onViewHistory: () => void;
  onLoadExample: (exampleKey: 'medical' | 'shipping' | 'astronomy') => void;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  onStartNew,
  onViewHistory,
  onLoadExample,
}) => {
  const [recentRuns, setRecentRuns] = useState<ConversionRun[]>([]);

  useEffect(() => {
    ApiService.getHistory(5)
      .then((data) => setRecentRuns(data || []))
      .catch(() => {});
  }, []);

  return (
    <div className="max-w-5xl mx-auto py-8 px-4 space-y-8">
      {/* Hero */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700/80 rounded-2xl p-8 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-sky-500/10 border border-sky-500/30 rounded-full text-sky-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Autonomous Document Conversion</span>
          </div>
          <h2 className="text-3xl font-extrabold text-white tracking-tight leading-tight">
            Convert Excel Workbooks into Word Templates Automatically
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            The uploaded files define the schema. The engine dynamically extracts source and target structures,
            evaluates matches across 9 intelligent stages, preserves original Word styling, and validates output integrity.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="button"
              onClick={onStartNew}
              className="flex items-center space-x-2 px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold rounded-lg shadow-md transition"
            >
              <span>Start New Conversion</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onViewHistory}
              className="flex items-center space-x-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition"
            >
              <History className="w-4 h-4" />
              <span>Audit History</span>
            </button>
          </div>
        </div>
      </div>

      {/* Feature Highlights Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-5 space-y-2">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <Layers className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-semibold text-white">Zero Hardcoded Parameters</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Works out-of-the-box on unknown column names, offset header rows, formulas, and diverse scientific or business domains.
          </p>
        </div>

        <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-5 space-y-2">
          <div className="w-9 h-9 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-semibold text-white">9-Stage Intelligent Matching</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Combines exact matching, normalization, synonyms, token fuzzy scoring, type compatibility, and user memory.
          </p>
        </div>

        <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-5 space-y-2">
          <div className="w-9 h-9 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-semibold text-white">Deep Formatting Preservation</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Maintains font families, weights, borders, cell shading, headers, footers, and margins by cloning OOXML structures.
          </p>
        </div>
      </div>

      {/* Quick Test Domains */}
      <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-6 space-y-4">
        <div>
          <h3 className="text-base font-semibold text-white">Try Example Multi-Domain Workflows</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Load synthetic test fixtures to observe schema discovery across unfamiliar domains:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div
            onClick={() => onLoadExample('medical')}
            className="p-4 rounded-lg border border-slate-700 bg-slate-900/60 hover:border-emerald-500/60 cursor-pointer transition space-y-2"
          >
            <div className="flex items-center space-x-2 text-emerald-400 text-xs font-semibold">
              <FileSpreadsheet className="w-4 h-4" />
              <span>Clinical Cohort</span>
            </div>
            <p className="text-xs text-slate-400">
              Systolic/diastolic blood pressure, condition classification, visit dates.
            </p>
          </div>

          <div
            onClick={() => onLoadExample('shipping')}
            className="p-4 rounded-lg border border-slate-700 bg-slate-900/60 hover:border-sky-500/60 cursor-pointer transition space-y-2"
          >
            <div className="flex items-center space-x-2 text-sky-400 text-xs font-semibold">
              <FileSpreadsheet className="w-4 h-4" />
              <span>Maritime Container Cargo</span>
            </div>
            <p className="text-xs text-slate-400">
              Vessel references, container tare/gross weight (KG), origin & destination ports.
            </p>
          </div>

          <div
            onClick={() => onLoadExample('astronomy')}
            className="p-4 rounded-lg border border-slate-700 bg-slate-900/60 hover:border-purple-500/60 cursor-pointer transition space-y-2"
          >
            <div className="flex items-center space-x-2 text-purple-400 text-xs font-semibold">
              <FileSpreadsheet className="w-4 h-4" />
              <span>Astrophysics Telemetry</span>
            </div>
            <p className="text-xs text-slate-400">
              Deep space radio signals, right ascension, declination, redshift metrics.
            </p>
          </div>
        </div>
      </div>

      {/* Recent Conversions */}
      {recentRuns.length > 0 && (
        <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-400" />
            Recent Conversion Runs
          </h3>
          <div className="space-y-2">
            {recentRuns.map((r) => (
              <div
                key={r.id}
                className="bg-slate-900/80 border border-slate-700/60 rounded-lg p-3 text-xs flex items-center justify-between"
              >
                <div className="space-y-0.5">
                  <span className="font-semibold text-slate-200">
                    {r.output_path.split('\\').pop()?.split('/').pop()}
                  </span>
                  <div className="text-[11px] text-slate-400">
                    {r.record_count} records converted • {new Date(r.created_at).toLocaleDateString()}
                  </div>
                </div>
                <span className="flex items-center space-x-1 text-emerald-400 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Success</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
